package com.example.taskgroup.service;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.example.taskgroup.testutils.JsonUtils;

import com.example.taskgroup.model.Groups;
import com.example.taskgroup.model.Task;

import org.mockito.Mockito;

import com.example.taskgroup.dao.GroupsRepository;

@ExtendWith(SpringExtension.class)
class GroupServiceImplTest {

	@TestConfiguration
	static class GroupServiceImplTestContextConfiguration {
		@Bean
		public GroupService groupService() {
			return new GroupServiceImpl();
		}
	}

	@Autowired
	private GroupServiceImpl groupService;

	@MockBean
	private GroupsRepository groupReository;

	@BeforeEach
	public void setup() {

		//Groups group1 = JsonUtils.createGroup((int) 1, "Daily", "Active");
		Task task = new Task();
    	task.setId(1);
    	task.setName("Praveen");
    	task.setPriority("1");
    	task.setStartDate("04-Jul-2020");
    	task.setEndDate("08-Jul-2020");
    	task.setStatus("Active");
    	List<Task> list= new ArrayList<Task>();
    	
    	Groups group = new Groups();
    	group.setId(1);
    	group.setName("Shekhar");
    	group.setStatus("Active");
    	group.setTasks(list);
    	
    	Task task1 = new Task();
    	task1.setId(1);
    	task1.setName("Praveen");
    	task1.setPriority("1");
    	task1.setStartDate("04-Jul-2020");
    	task1.setEndDate("08-Jul-2020");
    	task1.setStatus("Active");
    	List<Task> list1= new ArrayList<Task>();
    	
    	Groups group1 = new Groups();
    	group1.setId(1);
    	group1.setName("Shekhar");
    	group1.setStatus("Active");
    	group1.setTasks(list);
    	
    	List<Groups> list2 =  new ArrayList<Groups>();
    	list2.add(group);
    	list2.add(group1);
    //Mockito.when(groupReository.save(group)).thenReturn(group);
		Mockito.when(groupReository.findAll()).thenReturn(list2);
	}

	@Test
	public void testFindAll() {
		List<Groups> lists = (List<Groups>) groupReository.findAll();
		assertEquals(lists.size(),2);
	}
	@Test
	public void testDeleteGroup() {
		Task task = new Task();
    	task.setId(1);
    	task.setName("Ajay");
    	task.setPriority("1");
    	task.setStartDate("04-Jul-2020");
    	task.setEndDate("08-Jul-2020");
    	task.setStatus("Active");
    	List<Task> list= new ArrayList<Task>();
    	
    	Groups group = new Groups();
    	group.setId(1);
    	group.setName("Shekhar");
    	group.setStatus("Active");
    	group.setTasks(list);
		groupReository.delete(group);
		Optional<Groups> g = groupReository.findById(1);
	    g.getClass();
	    
		
	}
	
}
